Dado("que eu acessar o site da Movida") do
    @login = Login.new 
    @login.visitar_pagina
    #visit'https://www.movida.com.br/'
end
  
E("acessar a tela de Login") do
    find('element :login, #login-button').click
end
  
Quando("preencho os campos CPF e Senha") do
    fill_in("cpf", with: "32264237899")
    fill_in("senha", with: "147369")
    sleep(4)
    find("id=login-button").click  
end
  
Então("o Login é realizado com sucesso") do
    expect(page).to have_content (bem vindo!)
    sleep (3)
end
  
Quando("preencher os campos CPF e Senha com dados inválidos") do
    fill_in("cpf", with: "11111111")
    fill_in("senha", with: "111111")
    sleep(4)
    find("id=login-button").click  
end
  
Então("o Login não é realizado") do
    expect(page).to have_content("Usuário ou senha inválido(s)!")
    sleep (3)
end


  
  
  
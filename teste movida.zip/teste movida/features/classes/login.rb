class Login < SitePrism::Page

    element :login, 'input[id="login-button"]'


    def visitar_pagina
        visit 'https://www.movida.com.br/'
    end


end